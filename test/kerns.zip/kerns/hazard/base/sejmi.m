%pomocna procedurka na snimani obrazku



set(gcf,'Units','centimeters');

set(gcf,'Position',[3.5692 4.4945 1.1*26.0681 1.1*18.6918]);

set(gcf,'PaperPositionMode','auto');

set(gcf,'InvertHardcopy','off');

print('-deps','sejmi_temp.eps');

%movefile('pokus.eps','C:\Program Files\MATLAB\R2009a\work\toolbox\pokus.eps')

%movefile('pokus.eps','Q:\matlab\toolbox\pokus.eps')







