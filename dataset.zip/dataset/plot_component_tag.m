function plot_component_tag(components)
for i = 1:length(components)
    x = mean(components{i}.polygon.x);
    y = mean(components{i}.polygon.y);
    text(x, y, components{i}.tag, 'FontSize', 20, 'Color', 'r', 'HorizontalAlignment', 'center');
end
end